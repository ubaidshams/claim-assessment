<template>
  <div>
    <v-container fluid class="my-3 mx-auto d-flex">
      <div>
        <h3 class="text-capitalize mr-3">Claim number - 4340002739</h3>
      </div>
      <div class="featureClaim">
        <h3 class="text-uppercase feature">feature claim</h3>
      </div>
      <div>
        <span class="text-uppercase text-xs">view details</span>
      </div>
    </v-container>
    <claim-table />
    <claim-footer />
  </div>
</template>

<script>
import ClaimTable from "@/components/ClaimTable.vue";
import ClaimFooter from "@/components/ClaimFooter.vue";
export default {
  components: { ClaimTable, ClaimFooter },
};
</script>

<style scoped>
.container {
  width: 95%;
  background: #f5f5f5;
  border: 1px solid #eeedf0;
}
.feature {
  color: #d2161f;
}
</style>
