<template>
  <div class="dropdown d-flex">
    <v-container fluid class="header d-flex">
      <h3>Indemnity Details</h3>
      <v-spacer></v-spacer>
      <div class="headerBtns">
        <v-btn depressed>reset</v-btn>
        <v-btn depressed>save & close</v-btn>
      </div>
    </v-container>
    <v-simple-table> </v-simple-table>
  </div>
</template>

<script>
export default {
  name: "DropdownTable",
};
</script>

<style lang="scss" scoped>
.dropdown {
  width: 100%;
}
.header {
  width: 100%;
}
</style>
