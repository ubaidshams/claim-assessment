<template>
  <div class="ma-10">
    <v-simple-table height="500">
      <thead class="">
        <tr>
          <th v-for="header in tableHeader" :key="header">{{ header }}</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Leakage</td>
          <td>25,00,000</td>
          <td>16,25,123</td>
          <td>25,23,178</td>
          <td>
            <v-btn
              depressed
              color="transparent"
              @click="dropdownTable = !dropdownTable"
              >add/modify</v-btn
            >
          </td>
        </tr>
        <dropdown-table v-show="dropdownTable" />
        <tr>
          <td>Damage</td>
          <td>25,00,000</td>
          <td>16,25,123</td>
          <td>25,23,178</td>
          <td><v-btn depressed color="transparent">add/modify</v-btn></td>
        </tr>
        <tr>
          <td>Shortage</td>
          <td>25,00,000</td>
          <td>16,25,123</td>
          <td>25,23,178</td>
          <td><v-btn depressed color="transparent">add/modify</v-btn></td>
        </tr>
        <tr>
          <td>Non-Delivery of Total Consignment</td>
          <td>25,00,000</td>
          <td>16,25,123</td>
          <td>25,23,178</td>
          <td><v-btn depressed color="transparent">add/modify</v-btn></td>
        </tr>
        <tr>
          <td>Total*</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Agreed Value Amount*</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Gross Total*</td>
          <td>25,00,000</td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Repair, Repacking,Reprocessing etc.</td>
          <td>25,00,000</td>
          <td>16,25,123</td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Additional Freigh/Incidentals</td>
          <td>25,00,000</td>
          <td>16,25,123</td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Duties</td>
          <td></td>
          <td>16,25,123</td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Total Indemnity Amount (A)*</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Less Salvage (B)</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Less Other Adjustment (C)</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Less Deductible (D)</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Less Deduction - Recovery Rights (E)</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Total Payable Amount*</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Amount Held*</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Held %*</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
        <tr>
          <td>Net Amount Payable*</td>
          <td></td>
          <td></td>
          <td>25,23,178</td>
          <td></td>
        </tr>
      </tbody>
    </v-simple-table>
  </div>
</template>

<script>
import DropdownTable from "./DropdownTable.vue";
export default {
  components: { DropdownTable },
  name: "ClaimTable",
  data() {
    return {
      tableHeader: [
        "Indemnity Details",
        "Assessed Amount (Foreign Currency)",
        "Assessed Amount (INR)*",
        "Total INR Admissable Amount*",
        "Action",
      ],
      dropdownTable: false,
    };
  },
};
</script>

<style lang="scss" scoped>
thead {
  background: #23b1a9;
}
button {
  color: #2d21b2 !important;
}
</style>
