<template>
  <div ma-10>Footer</div>
</template>

<script>
export default {
  name: "ClaimFooter",
};
</script>

<style lang="scss" scoped></style>
